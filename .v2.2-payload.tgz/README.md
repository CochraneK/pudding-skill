# pudding-skill

A **Pudding-inspired editorial data-storytelling Agent Skill + SvelteKit starter** that turns structured data into an auditable set of story directions before it renders anything.

This project is not a visual clone of [The Pudding](https://pudding.cool/). It borrows the more useful editorial idea: start with a question and evidence, compare what the data can support, choose the right narrative/visual form, and verify the result before publishing.

> The Svelte starter is derived from [`the-pudding/svelte-starter`](https://github.com/the-pudding/svelte-starter) under the MIT License. This project is not affiliated with The Pudding and does not ship or hotlink The Pudding logos or proprietary fonts.

## v2.2: from chart heuristic to editorial decision system

v2.1 established a deterministic data → story → Svelte baseline. v2.2 removes the biggest remaining shortcut: **the first matching analytical pattern no longer automatically becomes the story.**

The pipeline now:

1. profiles the data;
2. optionally applies an explicit data contract for roles, labels, units, and definitions;
3. generates multiple defensible story candidates;
4. scores them with transparent editorial-priority proxies;
5. selects the highest-ranked candidate that passes quality + renderer gates, with automatic fallback;
6. creates a story spec and render bundle;
7. independently recomputes the selected quantitative evidence from raw data;
8. exposes the candidate board and audit trail in `/lab`;
9. renders the selected baseline at `/generated`;
10. runs the same gates in CI.

## Pipeline

```text
research question + structured data
              │
              ├──── optional data contract
              ▼
          DATA AUDIT
              ▼
      CANDIDATE GENERATION
              │
      ┌───────┼────────┬───────────┐
      ▼       ▼        ▼           ▼
   change   divergence relation distribution ...
      └───────┬────────┴───────────┘
              ▼
       TRANSPARENT SCORING
              ▼
     QUALITY / RENDERER GATES
          fail │  pass
               ├──► try next
               ▼
          STORY SPEC
              ▼
       INDEPENDENT CLAIM AUDIT
              ▼
       BASELINE RENDER BUNDLE
          ┌───┴────┐
          ▼        ▼
        /lab   /generated
              ▼
       BESPOKE EDITORIAL BUILD
```

The score is **not newsworthiness**. It ranks evidence-backed directions using computable proxies such as coverage, effect size, distinctiveness, visual fit, simplicity, question alignment, and risk penalties. Domain meaning and editorial significance still require judgment.

## Quick start

```bash
git clone https://github.com/CochraneK/pudding-skill.git
cd pudding-skill
npm install
npm run dev
```

Useful routes:

- `/` — Pudding-inspired scrollytelling design demo;
- `/lab` — ranked story candidates, score breakdown, fallback attempts, quality gates, and claim audit;
- `/generated` — the selected deterministic baseline story.

## Run the full editorial pipeline

```bash
python scripts/pipeline.py examples/sample-data.csv \
  --question "Which fictional cities saw housing costs separate most sharply from income after 2019?" \
  --schema examples/data-schema.example.json
```

Outputs:

```text
generated/profile.json
generated/candidates.json
generated/story-spec.json
generated/selection-report.json
generated/evaluation.json
generated/claim-audit.json
src/data/story-candidates.json
src/data/story-selection.json
src/data/story-evaluation.json
src/data/story-claim-audit.json
src/data/auto-story.json
```

## Why the data contract matters

Field names are not enough to establish semantics. An optional JSON contract can identify time/category/measure roles and provide publication labels, units, and definitions:

```json
{
  "fields": {
    "year": { "role": "time", "label": "Year" },
    "city": { "role": "category", "label": "City" },
    "income_index": {
      "role": "measure",
      "label": "Income index",
      "unit": "index, 2019 = 100"
    }
  }
}
```

Validate one with:

```bash
python scripts/data_contract.py examples/data-schema.example.json
```

## Candidate generation and selection

Inspect candidates directly:

```bash
python scripts/candidate_story.py data.csv \
  --question "What changed?" \
  --schema data-schema.json \
  --output candidates.json
```

Select with automatic fallback:

```bash
python scripts/select_story.py data.csv \
  --question "What changed?" \
  --schema data-schema.json
```

Current baseline patterns include:

- time + category + two measures → divergence in start-to-end change;
- time + category + measure → group change over time;
- category + measure → ranked group mean comparison;
- two numeric measures → correlation/scatter;
- numeric measure → distribution.

## Independent claim verification

The story spec does not get to “trust itself.” `verify_claims.py` reads raw rows again and recomputes structured evidence:

```bash
python scripts/verify_claims.py generated/story-spec.json examples/sample-data.csv
```

A mismatch is a hard failure. Tests include a tampering case where a correct gap of `31` is changed to `999`; the audit must reject it.

The audit verifies numbers, not interpretation. It cannot decide whether a denominator is meaningful, a causal story is valid, or a metric is ethically appropriate.

## Main scripts

| Script | Purpose |
|---|---|
| `profile_data.py` | schema/type/missingness/range audit |
| `data_contract.py` | validates explicit roles, labels, units, descriptions |
| `candidate_story.py` | generates and scores multiple story directions |
| `select_story.py` | applies quality/renderer gates and falls back when needed |
| `validate_story.py` | validates story-spec structure |
| `evaluate_story.py` | deterministic editorial quality gates |
| `verify_claims.py` | independently recomputes quantitative evidence |
| `generate_story.py` | creates normalized renderer data |
| `pipeline.py` | orchestrates the full v2.2 chain |
| `qa_story.py` | repository/static/brand preflight |

`derive_story.py` remains as the v2.1 single-direction baseline for compatibility and simple experiments; the preferred workflow is now `pipeline.py`.

## Repository structure

```text
pudding-skill/
├── SKILL.md
├── references/
│   ├── editorial-workflow.md
│   ├── editorial-scoring.md
│   ├── data-contract.md
│   ├── visual-grammar.md
│   ├── story-spec.md
│   ├── claim-audit.md
│   └── quality-rubric.md
├── scripts/
│   ├── profile_data.py
│   ├── data_contract.py
│   ├── candidate_story.py
│   ├── select_story.py
│   ├── derive_story.py
│   ├── validate_story.py
│   ├── evaluate_story.py
│   ├── verify_claims.py
│   ├── generate_story.py
│   ├── pipeline.py
│   └── qa_story.py
├── examples/
│   ├── sample-data.csv
│   ├── data-schema.example.json
│   └── story-spec.example.json
├── src/routes/
│   ├── +page.svelte
│   ├── generated/+page.svelte
│   └── lab/+page.svelte
├── tests/test_pipeline.py
└── .github/workflows/ci.yml
```

## Checks

```bash
npm run check:skill
npm run build
```

`check:skill` validates the example contract/spec, runs the full candidate-selection pipeline, independently audits the selected quantitative evidence, runs unit tests, and performs static preflight checks.

## Editorial principles

1. **Evidence before aesthetics.**
2. **Competing hypotheses before commitment.** Do not stop at the first chartable pattern.
3. **Explicit semantics before inference.** Units and roles should be stated when ambiguous.
4. **One primary argument.** Supporting facts should reinforce it.
5. **Narrative operations before chart names.**
6. **Use scroll only when sequence matters.**
7. **Numeric claims must be reproducible from source data.**
8. **Mobile and accessibility are correctness concerns, not polish.**
9. **Scores assist judgment; they do not replace it.**

## Licensing and attribution

- Upstream starter: [`the-pudding/svelte-starter`](https://github.com/the-pudding/svelte-starter), MIT License.
- Skill instructions, scripts, examples, and demo additions: MIT License under this repository.
- The Pudding name is used only for attribution and to describe editorial inspiration. No affiliation is implied.
